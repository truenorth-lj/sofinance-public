import { engineEnv } from "../host";
import { Connection, type Commitment } from "@solana/web3.js";
import { resetRpcCache, setRpcCache } from "./cache";
import { resetRpcCircuit } from "./circuit";
import { createResilientConnection } from "./connection";
import { setRpcLogger } from "./logger";
import { resolveDefaultRpcConfig, resolveProviderPair, resolveRpcConfig } from "./providers";
import { setRpcRetryConfig, type RetryConfig } from "./retry";
import type { RpcEnv } from "./types";

export type { RpcConfig, RpcEnv, RpcMetricId, RpcProvider, RpcProviderId, RpcCallMetric, RpcErrorKind, RpcFallbackReason, RpcLogEvent, RpcLogger } from "./types";
export type { RpcCacheStore } from "./cache";
export {
  PUBLIC_SOLANA_RPC_URL,
  RPC_PROVIDERS,
  SOLAMI_RPC_BASE_URL,
  providerSupportsCustomMethod,
  redactRpcEndpoint,
  resolveDefaultRpcConfig,
  resolveProvider,
  resolveProviderPair,
  resolveRpcConfig,
  rpcProvider,
} from "./providers";
export { classifyRpcError, isRpcStructValidationError, shouldFallback, RpcHttpError, RpcUnavailableError, RPC_UNAVAILABLE_MESSAGE, asRpcUserError } from "./errors";
export { DEFAULT_METHOD_POLICY, METHOD_POLICIES, methodAllowsFallback, policyFor, cacheTtlFor, UNCACHEABLE_METHODS } from "./methods";
export { createResilientConnection, invokeWithPolicy, lastRpcCallMetric } from "./connection";
export { rpcRequest } from "./json-rpc";
export { MemoryRpcCache, getRpcCache, setRpcCache, resetRpcCache, cacheKeyFor } from "./cache";
export { setRpcLogger } from "./logger";
export { setRpcRetryConfig, computeBackoffMs, parseRetryAfter, invokeWithRetries, DEFAULT_RETRY, PREVIEW_RETRY } from "./retry";
export type { RetryConfig } from "./retry";
export { rpcLogEnabled, formatRpcLog, defaultRpcLogger } from "./logger";
export {
  DEFAULT_CIRCUIT,
  circuitErrorKind,
  isPrimaryCircuitOpen,
  notePrimaryFailure,
  notePrimarySuccess,
  resetRpcCircuit,
  rpcCircuitConfig,
  setRpcCircuitClock,
  setRpcCircuitConfig,
} from "./circuit";
export type { RpcCircuitConfig } from "./circuit";

export type RpcConnectionInit = {
  fetch?: typeof fetch;
  signal?: AbortSignal;
  commitment?: Commitment;
  env?: RpcEnv;
  retry?: Partial<RetryConfig> | null;
};

function mergeSignals(left?: AbortSignal | null, right?: AbortSignal | null): AbortSignal | undefined {
  const first = left ?? undefined;
  const second = right ?? undefined;
  if (first && second) return AbortSignal.any([first, second]);
  return first ?? second;
}

function createEndpointConnection(endpoint: string, init: RpcConnectionInit = {}): Connection {
  const fetchImpl = init.fetch || init.signal
    ? (url: RequestInfo | URL, fetchInit?: RequestInit) => {
        const signal = mergeSignals(init.signal, fetchInit?.signal);
        return (init.fetch ?? fetch)(url, { ...fetchInit, signal });
      }
    : undefined;
  return new Connection(endpoint, {
    commitment: init.commitment ?? "confirmed",
    disableRetryOnRateLimit: true,
    ...(fetchImpl ? { fetch: fetchImpl } : {}),
  });
}

/**
 * Prefer Solami when `SOLAMI_API_KEY` is set, else `SOLANA_RPC_URL`, else
 * public mainnet. Keys stay server-side. When Solami is primary, web3.js
 * methods that it answers non-compliantly fall back per `METHOD_POLICIES`.
 * Auth / rate-limit / 5xx / timeout fail over for reads and for send/confirm
 * (re-broadcast of the same signed tx is idempotent by signature). A short
 * circuit-breaker skips a dead primary until the cooldown elapses.
 */
export function rpcConnection(env: RpcEnv = engineEnv() as RpcEnv, init: RpcConnectionInit = {}) {
  const resolved = init.env ?? env;
  const pair = resolveProviderPair(resolved);
  const primary = createEndpointConnection(pair.primary.endpoint, init);
  const fallback = pair.fallback ? createEndpointConnection(pair.fallback.endpoint, init) : null;
  return createResilientConnection(primary, fallback, {
    primaryId: pair.primary.metricId,
    fallbackId: pair.fallback?.metricId ?? "default",
    signal: init.signal,
    retry: init.retry,
  });
}

export function defaultRpcConnection(env: RpcEnv = engineEnv() as RpcEnv, init: RpcConnectionInit = {}) {
  return createResilientConnection(
    createEndpointConnection(resolveDefaultRpcConfig(init.env ?? env).endpoint, init),
    null,
    { primaryId: "default", fallbackId: "default", signal: init.signal, retry: init.retry },
  );
}

export function rpcConfig(env: RpcEnv = engineEnv() as RpcEnv) {
  return resolveRpcConfig(env);
}

/** Test helper: clear cache, inflight map, logger, retry overrides, and circuit. */
export function resetRpcRuntime() {
  resetRpcCache();
  setRpcCache(null);
  setRpcLogger(null);
  setRpcRetryConfig(null);
  resetRpcCircuit();
}
