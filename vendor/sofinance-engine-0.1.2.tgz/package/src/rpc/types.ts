/** Metric / history label. Dedicated RPCs (Helius, etc.) report as `default`. */
export type RpcMetricId = "solami" | "default";

/** Config catalog id. `generic` is SOLANA_RPC_URL (Helius or any JSON-RPC). */
export type RpcProviderId = "solami" | "generic" | "public";

/** @deprecated Use RpcMetricId. Kept so existing history/UI labels stay stable. */
export type RpcProvider = RpcMetricId;

export type RpcEnv = Record<string, string | undefined>;

export type RpcErrorKind =
  | "validation"
  | "auth"
  | "http-4xx"
  | "http-5xx"
  | "rate-limit"
  | "timeout"
  | "empty"
  | "other";

export type RpcFallbackReason = "circuit-open" | "primary-error";

export type MethodPolicy = {
  /**
   * When true, listed `fallbackOn` kinds may run on the next provider.
   * Send/confirm re-broadcast the same signed payload (idempotent by signature).
   */
  fallback: boolean;
  fallbackOn: readonly RpcErrorKind[];
  /** Treat this successful return value as empty and apply empty-fallback. */
  emptyWhen?: (value: unknown) => boolean;
};

export type RpcCallMetric = {
  method: string;
  servedBy: RpcMetricId;
  fallback: boolean;
  errorKind?: RpcErrorKind;
  retries?: number;
  cacheHit?: boolean;
};

export type ResolvedProvider = {
  id: RpcProviderId;
  metricId: RpcMetricId;
  label: string;
  endpoint: string;
  customMethods: readonly string[];
};

export type ProviderPair = {
  primary: ResolvedProvider;
  fallback: ResolvedProvider | null;
};

export type RpcConfig = {
  endpoint: string;
  provider: RpcMetricId;
};

export type RpcLogEvent = {
  method: string;
  provider: RpcMetricId;
  outcome: "ok" | "retry" | "fallback" | "cache-hit" | "error";
  attempt?: number;
  retries?: number;
  cacheHit?: boolean;
  errorKind?: RpcErrorKind;
  reason?: RpcFallbackReason;
};

export type RpcLogger = (event: RpcLogEvent) => void;
