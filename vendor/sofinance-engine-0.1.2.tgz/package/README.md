# @sofinance/engine

The SoFinance transaction engine, moved here from `truenorth-lj/sofinance-public` (`src/lib`, as of
`f61a764`, PR #107). It is the single source of truth for both apps:

- **sofinance-public** (sofinancelab.xyz) consumes a packed release of this package (see "Releases").
- **this prototype** will consume it as a workspace package in P3 (deposits are still disabled).

## What is inside

Open (`open-atomic`, `open-quote`, `open-state`, `open-simulation`, `open-transaction`, `open-rent`, ...),
compound (`compound-*`, `swap/compound`), withdraw (`withdraw/*`, `lp-exit-*`), the shared swap / fee
layer (`swap/*`, 10 bps default to `SOFINANCE_FEE_WALLET`), Jupiter and resilient RPC clients
(`jupiter/*`, `rpc/*`), Solami Beam tips, and their tests and golden fixtures. Deep imports mirror the
original layout: `src/lib/open-atomic.ts` → `@sofinance/engine/open-atomic`, `src/lib/rpc/index.ts` →
`@sofinance/engine/rpc`. Source ships as TypeScript; hosts transpile it (Next `transpilePackages`).

Not inside: Next routes, Postgres stores, React, permits issued by routes, the prototype's sponsor key.

## Host injection (no ambient env reads)

The engine never reads `process.env`. A host calls once:

```ts
import { configureEngine } from "@sofinance/engine/host";
configureEngine({ env: () => process.env }); // or any snapshot/provider
```

The provider is called on every read (same semantics as the old inline reads). Unconfigured use throws.
Every top-level builder also accepts an injected `connection`.

## Fee payer separation (sponsored mode)

`buildAndSimulateOpenPosition(..., { feePayer })`, `buildAndSimulateCompound(wallet, mint, sources, { feePayer })`
and `buildWithdraw(request, preview, { feePayer })`:

- owner mode (omit `feePayer`, or pass the wallet): unchanged, byte-for-byte (tests + golden snapshots);
- sponsored mode: the fee payer is the message payer and first signer, funds every new account
  (ATAs, Raydium position NFT/account via `open_position_with_token22_nft` payer, isolated accounts,
  fee-recipient ATA), the wallet's SOL is required not to move (`maxSolDebitLamports = 0`, zero-SOL wallets allowed),
  Beam tips are skipped, native-SOL input/output is refused, and recovered rent goes back to the sponsor
  (position close rent via an exact `SystemProgram.transfer`, isolated account closes directly to the sponsor,
  compound prior-account refunds passed through).
- The engine does **not** verify the sponsor's own SOL spend; the host's sponsor guard must (P3).

## Multi-transaction plans

`plan.ts`: `TransactionPlan` (`atomic`, ordered `steps` with required signers and sizes),
`planFromSingleResult`, `planFromWithdrawResult` (withdraw already splits into withdraw + swap stage),
and `packInstructionGroups` for greedy, order-preserving packing into ≤1,232-byte packets.

## Tests

`pnpm --filter @sofinance/engine test` / `typecheck` (also run by the root `pnpm test` / `pnpm typecheck`).

## Releases

Tag `engine-vX.Y.Z` on this repo, then `pnpm --filter @sofinance/engine pack` and vendor the tarball
into sofinance-public (`vendor/sofinance-engine-X.Y.Z.tgz`) with its `scripts/update-engine.sh`.
